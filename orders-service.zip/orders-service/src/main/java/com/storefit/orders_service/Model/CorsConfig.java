package com.storefit.orders_service.Model;

public class CorsConfig {

}
